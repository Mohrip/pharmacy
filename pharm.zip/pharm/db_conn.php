<?php 

$conn = mysqli_connect('localhost','root','','481_db');